.. cmake-module:: ../../Modules/FindFreetype.cmake
